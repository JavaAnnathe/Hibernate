package client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import util.HibernateUtil;

import domain.Message;


public class HelloWorldClient {
	public static void main(String[] args) {
		
				
				SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
				Session session =  sessionFactory.openSession();
		
				session.beginTransaction();
        
        		Message message = new Message( "Time and tide wait for no men" );
        
        		session.save(message);    
        
        		session.getTransaction().commit();
        		session.close();
        		System.out.println("Message object persisted");
	
	}
}

