package client;

import org.hibernate.Session;

import entity.Message;
import util.HibernateUtil;

public class Main1 {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		Message message = (Message)session.get(Message.class, 703L);
		
		System.out.println("Message:"+message);
		
		session.delete(message);
		
		session.getTransaction().commit();
		session.close();
		System.out.println("deleted");
	}

}
