package client;

import org.hibernate.Session;

import entity.Message;
import util.HibernateUtil;

public class Main2 {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		Message message = (Message)session.get(Message.class, 702L);
		
		System.out.println("Message:"+message);
		
		message.setText("Srikant");
		
		session.update(message);
		
		session.getTransaction().commit();
		session.close();
		System.out.println("Updated");

	}

}
